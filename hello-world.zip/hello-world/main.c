#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int main(int argc, char **argv) {
    printf("Hello World!\n");
    return 0;
}
